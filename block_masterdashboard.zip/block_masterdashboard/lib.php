<?php
// Required for Moodle plugin compliance.
