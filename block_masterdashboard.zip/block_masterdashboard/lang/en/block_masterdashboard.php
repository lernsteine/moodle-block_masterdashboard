<?php
$string['pluginname'] = 'Master Dashboard';
$string['masterdashboard:addinstance'] = 'Add a new Master Dashboard block';
$string['masterdashboard:myaddinstance'] = 'Add a new Master Dashboard block to My Moodle page';
